#ifndef W2C2_LEB128_TEST_H
#define W2C2_LEB128_TEST_H

void
testReadU32LEB128(void);

void
testReadI32LEB128(void);

#endif /* W2C2_LEB128_TEST_H */
