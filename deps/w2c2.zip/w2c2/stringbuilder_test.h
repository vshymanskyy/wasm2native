#ifndef W2C2_STRINGBUILDER_TEST_H
#define W2C2_STRINGBUILDER_TEST_H

void
testStringBuilder(void);

#endif /* W2C2_STRINGBUILDER_TEST_H */
