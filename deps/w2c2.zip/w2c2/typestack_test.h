#ifndef W2C2_TYPESTACK_TEST_H
#define W2C2_TYPESTACK_TEST_H

void
testTypeStack(void);

#endif /* W2C2_TYPESTACK_TEST_H */
