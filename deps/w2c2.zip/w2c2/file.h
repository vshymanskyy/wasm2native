#ifndef W2C2_FILE_H
#define W2C2_FILE_H

#include "buffer.h"

Buffer
readFile(
    const char* path
);

#endif /* W2C2_FILE_H */
